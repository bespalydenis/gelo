import ICON_GOOGLE from './svgs/icn_google.svg';
import ICON_EYE from './svgs/icn_show.svg';
import ICON_SUCCESS from './svgs/icn_success.svg';

export const GOOGLE = ICON_GOOGLE;
export const EYE = ICON_EYE;
export const SUCCESS = ICON_SUCCESS;